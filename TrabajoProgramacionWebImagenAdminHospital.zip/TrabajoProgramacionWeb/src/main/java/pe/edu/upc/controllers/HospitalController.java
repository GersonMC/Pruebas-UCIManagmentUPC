package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entities.Hospital;
import pe.edu.upc.serviceinterfaces.IHospitalService;

@Named
@RequestScoped
public class HospitalController {
	@Inject
	private IHospitalService pService;

	// atributos
	private Hospital p;
	private List<Hospital> listaHospitales;

	// inicializar
	@PostConstruct
	public void init() {
		this.listaHospitales = new ArrayList<Hospital>();
		this.p = new Hospital();
		this.list();
	}

	// M�todos para atender peticiones

	public String newHospital() {
		this.setP(new Hospital());
		return "hospital.xhtml";
	}

	public void insert() {
		try {
			pService.insert(p);

		} catch (Exception e) {

			System.out.println("Error al insertar en el controller" + e.getStackTrace());
		}

	}

	public void list() {
		try {
			listaHospitales = pService.list();
		} catch (Exception e) {
			System.out.println("Error al listar en el controller");
		}
	}

	public void delete(Hospital per) {
		try {
			pService.delete(per.getIdHospital());
			this.list();
		} catch (Exception e) {
			System.out.println("Error al eliminar en el controller hospital");
		}
	}

	// getter and setter
	public Hospital getP() {
		return p;
	}

	public void setP(Hospital p) {
		this.p = p;
	}

	public List<Hospital> getListaHospitales() {
		return listaHospitales;
	}

	public void setListaHospitales(List<Hospital> listaHospitales) {
		this.listaHospitales = listaHospitales;
	}

}
