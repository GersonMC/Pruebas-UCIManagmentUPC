package pe.edu.upc.daointerfaces;

import java.util.List;

import pe.edu.upc.entities.Hospital;

public interface IHospitalDao {
	
	public void insert(Hospital p);
	public List<Hospital> list();
	public void delete(int idHospital);
	
}
