package pe.edu.upc.daoimpls;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.daointerfaces.IAdministradorDao;
import pe.edu.upc.entities.Administrador;
import pe.edu.upc.entities.Hospital;

public class AdministradorImpl implements IAdministradorDao {
	@PersistenceContext(unitName = "TrabajoProgramacionWeb")
	private EntityManager ad;

	@Transactional
	@Override
	public void insert(Administrador a) {
		try {
			ad.persist(a);
		} catch (Exception e) {
			System.out.println("Error al insertar Administrador en el DAO");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Administrador> list() {
		List<Administrador> listaAdministradores = new ArrayList<Administrador>();
		try {
			Query jpql = ad.createQuery("from Administrador a");
			listaAdministradores = (List<Administrador>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println("Error al listar Administrador en DAO");
		}
		return listaAdministradores;
	}

	@Override
	public void delete(int idAdministrador) {
		try {
			Administrador adm = ad.find(Administrador.class, idAdministrador);
			ad.remove(adm);
		} catch (Exception e) {
			System.out.println("Error al eliminar en el DAO");
		}
	}

}
