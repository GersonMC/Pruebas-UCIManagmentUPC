package pe.edu.upc.serviceinterfaces;

import java.util.List;

import pe.edu.upc.entities.Hospital;

public interface IHospitalService {

	public void insert(Hospital p);

	public List<Hospital> list();

	public void delete(int idHospital);
}
