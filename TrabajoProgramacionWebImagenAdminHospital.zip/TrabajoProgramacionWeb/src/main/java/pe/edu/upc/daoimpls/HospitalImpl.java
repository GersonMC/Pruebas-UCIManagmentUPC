package pe.edu.upc.daoimpls;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.daointerfaces.IHospitalDao;
import pe.edu.upc.entities.Hospital;

public class HospitalImpl implements IHospitalDao {
	@PersistenceContext(unitName = "TrabajoProgramacionWeb")
	private EntityManager em;

	@Transactional
	@Override
	public void insert(Hospital p) {
		try {
			em.persist(p);
		} catch (Exception e) {
			System.out.println("Error al insertar hospital en el DAO");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Hospital> list() {
		List<Hospital> listaHospitales = new ArrayList<Hospital>();
		try {
			Query jpql = em.createQuery("from Hospital p");
			listaHospitales = (List<Hospital>) jpql.getResultList();
		} catch (Exception e) {
			System.out.println("Error al listar hospital en DAO");
		}

		return listaHospitales;
	}
	
	@Transactional
	@Override
	public void delete(int idHospital) {
		try {
			Hospital per = em.find(Hospital.class, idHospital);
			em.remove(per);
		} catch (Exception e) {
			System.out.println("Error al eliminar en el DAO");
		}

	}

}
